import { IconDefinition } from "@fortawesome/fontawesome-common-types";
declare const iconDef: IconDefinition;
export = iconDef;
